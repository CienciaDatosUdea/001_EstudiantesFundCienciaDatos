OK_FORMAT = True

test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> sol_q7 = np.round(0.428571428571, 2)\n'
                                               '>>> \n'
                                               '>>> def test_q7():\n'
                                               "...     assert model_proportions[0] == 0.44 and model_proportions[1] == 0.56, 'model_proportions no tiene los valores correctos'\n"
                                               "...     assert num_events == 210, 'El número de eventos no es el adecuado'\n"
                                               "...     assert len(simulation_results) == 2, 'El tamaño del arreglo no es el correcto'\n"
                                               "...     assert 0 <= simulation_proportion <= 1, 'La estadistica no está entre 0 y 1'\n"
                                               "...     assert np.round(simulation_proportion, 2) == sol_q7, 'La solución no es la correcta'\n"
                                               '>>> test_q7()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
