OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.random.seed(16)\n>>> num_events = 210\n>>> assert np.isclose(simulation_and_statistic(make_array(0.4, 0.5), num_events=210), 10.47, 0.01)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
