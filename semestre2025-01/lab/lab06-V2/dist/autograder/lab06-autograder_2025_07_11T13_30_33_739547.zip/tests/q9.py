OK_FORMAT = True

test = {   'name': 'q9',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> valor_esperado = np.round(0.991)\n'
                                               '>>> \n'
                                               '>>> def test_q9():\n'
                                               '...     assert np.isclose(np.round(proportion_greater_equal), valor_esperado)\n'
                                               '>>> test_q9()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
