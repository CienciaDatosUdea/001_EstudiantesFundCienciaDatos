OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q3():\n'
                                               "...     assert len(valid_stat) == 1, 'El tamaño del array no es el correcto'\n"
                                               "...     assert 2 in valid_stat, 'La segunda respuesta no es valida'\n"
                                               '>>> test_q3()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
