OK_FORMAT = True

test = {   'name': 'q6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> sol = 6.0\n'
                                               '>>> \n'
                                               '>>> def test_q6():\n'
                                               "...     assert isinstance(estadistica_observada, float), 'El valor no es del tipo float'\n"
                                               "...     assert np.round(estadistica_observada, 2) == sol, 'El resultado no es el correcto'\n"
                                               '>>> test_q6()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
