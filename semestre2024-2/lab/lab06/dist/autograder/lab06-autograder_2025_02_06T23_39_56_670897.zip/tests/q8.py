OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> num_events = 210\n'
                                               '>>> \n'
                                               '>>> def test_q8():\n'
                                               "...     assert 0 <= simulation_and_statistic(model_proportions, num_events) <= 1, 'El valor no está entre 0 y 1'\n"
                                               "...     assert isinstance(simulation_and_statistic(model_proportions, 210), float), 'El resultado no es un entero'\n"
                                               '>>> test_q8()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
