OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> sol_q2 = 0.5\n'
                                               '>>> \n'
                                               '>>> def test_q2():\n'
                                               "...     assert isinstance(proporcion_correcta, float), 'El valor no es un entero'\n"
                                               "...     assert 0 <= proporcion_correcta <= 1, 'El valor no esta entre 0 y 1'\n"
                                               "...     assert proporcion_correcta == sol_q2, 'El valor no es el adecuado'\n"
                                               '>>> test_q2()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
