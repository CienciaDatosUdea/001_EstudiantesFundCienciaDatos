OK_FORMAT = True

test = {   'name': 'q10',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> respuesta1 = True\n'
                                               '>>> respuesta2 = False\n'
                                               '>>> \n'
                                               '>>> def test_q10():\n'
                                               "...     assert len(peer_talk) == 2, 'Las dimensiones no son las correctas'\n"
                                               "...     assert type(peer_talk) == type(np.array([True, True])), 'No es un arreglo de numpy'\n"
                                               "...     assert peer_talk[0] == respuesta1 and peer_talk[1] == respuesta2, 'Las respuestas no son las correctas'\n"
                                               '>>> test_q10()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
