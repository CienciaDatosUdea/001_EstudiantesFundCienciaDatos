OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q5():\n'
                                               "...     assert np.round(estadist(0.5, 0.2), 2) == 0.3 * 100, 'Test 1 no superado'\n"
                                               "...     assert np.round(estadist(0.5, 0.45), 2) == 0.05 * 100, 'Test 2 no superado'\n"
                                               "...     assert estadist(0.3, 0.3) == 0.0, 'Test 3 no superado'\n"
                                               '>>> test_q5()\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
