OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> resultado = mis_estadisticos\n'
                                               ">>> assert len(resultado) == 2, 'El arreglo debe tener exactamente dos elementos.'\n"
                                               ">>> assert 1.0 < resultado[0] < 6.5, 'La longitud promedio del pétalo está fuera de rango esperado.'\n"
                                               ">>> assert 2.0 < resultado[1] < 4.5, 'El ancho promedio del sépalo está fuera de rango esperado.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
