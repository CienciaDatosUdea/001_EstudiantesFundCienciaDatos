OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert np.count_nonzero(numero_quesos == 'queso') < 5 and mas == 'mas por favor' or (np.count_nonzero(number_cheese == 'quesos') >= 5 and 'mas' "
                                               'not in locals())\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
