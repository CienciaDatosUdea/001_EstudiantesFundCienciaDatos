OK_FORMAT = True

test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(estadisticos) == 2, 'El resultado debe contener exactamente 2 elementos.'\n"
                                               ">>> assert 1.0 < estadisticos[0] < 6.5, 'La longitud promedio del pétalo parece fuera de rango.'\n"
                                               ">>> assert 2.0 < estadisticos[1] < 4.5, 'El ancho promedio del sépalo parece fuera de rango.'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
