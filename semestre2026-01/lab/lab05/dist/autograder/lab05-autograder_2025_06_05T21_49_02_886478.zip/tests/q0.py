OK_FORMAT = True

test = {   'name': 'q0',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> numero_quesos = 4\n>>> assert type(numero_quesos) == int\n>>> assert np.isclose(numero_quesos, 2.5, 1.38 * 2)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
