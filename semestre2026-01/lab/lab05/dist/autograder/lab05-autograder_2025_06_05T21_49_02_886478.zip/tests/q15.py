OK_FORMAT = True

test = {   'name': 'q15',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert diez_nachos_reacciones.labels[1] == 'Reacciones'\n>>> assert type(numero_wow_reacciones) == int\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
