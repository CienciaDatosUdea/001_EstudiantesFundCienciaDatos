OK_FORMAT = True

test = {   'name': 'q9',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> assert 1000 <= puntuacion_total_ana <= 6000\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
