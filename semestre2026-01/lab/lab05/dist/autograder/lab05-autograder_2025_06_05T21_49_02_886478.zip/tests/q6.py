OK_FORMAT = True

test = {   'name': 'q6',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> assert 8000 <= numero_diferentes <= 10000, f'Resultado fuera de lo esperado: {numero_diferentes}'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
