OK_FORMAT = True

test = {   'name': 'q14',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert diez_nachos_reacciones.num_rows == 10\n>>> assert all((col in diez_nachos_reacciones.labels for col in ['Nachos', 'Reacciones']))\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
