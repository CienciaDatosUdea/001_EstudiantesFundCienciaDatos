OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert nacho_reaccion('guacamole') == '¡cremosito!'\n"
                                               ">>> assert nacho_reaccion('queso') == '¡quesudo!'\n"
                                               ">>> assert nacho_reaccion('ninguno') == '¡meh!'\n"
                                               ">>> assert nacho_reaccion('ambos') == '¡wow!'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
