OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(mas_de_cinco, int), 'mas_de_cinco debe ser un entero'\n"
                                               ">>> assert mas_de_cinco > 0, 'mas_de_cinco debe ser positivo'\n"
                                               ">>> assert mas_de_cinco < len(palabras), 'mas_de_cinco no puede ser mayor que el total de palabras'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
